//
//  ViewController.swift
//  Task
//
//  Created by brn.developers on 7/31/18.
//  Copyright © 2018 Avast Technology. All rights reserved.
//

import UIKit

class LoginVC: UIViewController,UITextFieldDelegate {
    @IBOutlet weak var UserNameTF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        UserNameTF.delegate=self
        passwordTF.delegate=self
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBOutlet weak var passwordTF: UITextField!
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    func loginParsing()
    {
        let parameters = "email=\(UserNameTF.text!)&password=\(passwordTF.text!)&device_id=\(NSUUID().uuidString)&imei_no=359231064602723&device=IOS"
        Service.shared.POSTService(serviceType: "login", postString: parameters) { (results) -> (Void) in
            print(results)
            DispatchQueue.main.async {
                let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "HomeTVC") as! HomeTVC
                self.present(homeVC, animated: true, completion: nil)
            }
        }
    }
    @IBAction func signInBtn(_ sender: UIButton) {
        loginParsing()
    }
    
}

