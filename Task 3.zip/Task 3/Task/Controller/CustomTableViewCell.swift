//
//  CustomTableViewCell.swift
//  Task
//
//  Created by brn.developers on 8/1/18.
//  Copyright © 2018 Avast Technology. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {
    @IBOutlet weak var actualPrice: UILabel!
    @IBOutlet weak var productImage: UIImageView!
    
    @IBOutlet weak var finalPrice: UILabel!
    @IBOutlet weak var productDescription: UITextView!
    @IBOutlet weak var productName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
          self.layer.cornerRadius = 10
        self.layer.masksToBounds = true
        productImage.layer.cornerRadius = productImage.frame.width/2
        productImage.layer.masksToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
