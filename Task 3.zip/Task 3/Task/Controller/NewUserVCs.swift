//
//  NewUserVCs.swift
//  Task
//
//  Created by brn.developers on 8/1/18.
//  Copyright © 2018 Avast Technology. All rights reserved.
//

import UIKit

class NewUserVCs: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func onLoginAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func onSignupAction(_ sender: Any) {
        newUserSignUP()
    }
    func newUserSignUP()
    {
        let parameters = "email=amit@gmail.com&password=12345678&confirm_password=12345678&user_name=Amit&mobile_no=1231231231&device_id=53F89139-CD3F-429C-B4B9-61EF062BE75C&imei_no=359231064602723&religion=4&user_type=4"
        Service.shared.POSTService(serviceType: "register", postString: parameters) { (results) -> (Void) in
            print(results)
        }
    }
}
