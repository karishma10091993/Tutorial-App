//
//  HomeTVC.swift
//  Task
//
//  Created by brn.developers on 8/1/18.
//  Copyright © 2018 Avast Technology. All rights reserved.
//

import UIKit

class HomeTVC: UITableViewController {
    var productList = [(pImage:UIImage,PName:String,PDescription:String,PActualPrice:String,PFinalPrice:String)]()

    @IBOutlet weak var progressView: UIActivityIndicatorView!
    override func viewDidLoad() {
        super.viewDidLoad()
        homeParsing()
        self.progressView.startAnimating()
    }
    func homeParsing()
    {
        let parameter = "page=1"
        let urls = URL(string: "http://185.53.174.186/~exceptio/pracodev/webservice.php/getProductList")
        var urlRequests = URLRequest(url: urls!)
        urlRequests.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        urlRequests.httpMethod = "POST"
        urlRequests.httpBody = parameter.data(using: .utf8)
        URLSession.shared.dataTask(with: urlRequests) { (data, response, error) in
            DispatchQueue.main.async {
                if error != nil
                {
                    print(error!)
                }else
                {
                    do
                    {
                        let datas = try JSONDecoder().decode(products.self, from: data!)
                        print(datas.product_list.count)
                        for product in datas.product_list
                        {
                            let url1 = URL(string: product.product_image)
                            do
                            {
                            let datais = try Data(contentsOf: url1!)
                            self.productList.append((pImage:UIImage(data: datais)!, PName:product.name, PDescription: product.product_description, PActualPrice:product.actual_price, PFinalPrice:product.final_price))
                            }catch
                            {
                                print("Error")
                            }
                        }
                        self.progressView.stopAnimating()
                        self.tableView.reloadData()
                    }catch
                    {
                        print("error")
                    }
                }
            }
        }.resume()
        
        
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return productList.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cells", for: indexPath) as! CustomTableViewCell
        cell.layer.borderWidth = 3
        cell.layer.borderColor = UIColor.lightGray.cgColor
        cell.productImage.image = productList[indexPath.row].pImage
        cell.productName.text = productList[indexPath.row].PName
        cell.productDescription.text = productList[indexPath.row].PDescription
        cell.actualPrice.text = productList[indexPath.row].PActualPrice
        cell.finalPrice.text = productList[indexPath.row].PFinalPrice
        return cell
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
}
