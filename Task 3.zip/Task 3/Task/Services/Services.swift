//
//  Services.swift
//  Task
//
//  Created by brn.developers on 8/1/18.
//  Copyright © 2018 Avast Technology. All rights reserved.
//

import Foundation

class Service {
    
    static let shared = Service()
    init() { }
    
    let BASE_URL = "http://185.53.174.186/~exceptio/pracodev/webservice.php/"
    
    
    func GETService(extraParam : String, onTaskCompleted : @escaping (Any)->(Void) ) {
        
        guard let url = URL(string: "\(BASE_URL)/\(extraParam)") else { return }
        
        let urlRequest = URLRequest(url: url)
        
        URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            if error != nil {
                print(error as Any)
            } else {
                
                do {
                    
                    guard let dataIs = data else { return }
                    let serverResponse = try JSONSerialization.jsonObject(with: dataIs, options: .allowFragments)
                    
                    onTaskCompleted(serverResponse)
                    
                } catch {
                    print(error)
                }
                
            }
            }.resume()
    }
    func POSTService(serviceType : String, postString : String, onTaskCompleted : @escaping (Any)->(Void)) {
        
        guard let url = URL(string: "\(BASE_URL)/\(serviceType)") else { return }
        
        var urlRequest = URLRequest(url: url)
        
        urlRequest.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        urlRequest.httpMethod = "POST"
        urlRequest.httpBody = postString.data(using: .utf8)
        
        URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            if error != nil {
                print(error as Any)
            } else {
                
                do {
                    
                    guard let dataIs = data else { return }
                    let serverResponse = try JSONSerialization.jsonObject(with: dataIs, options: .allowFragments)
                    
                    onTaskCompleted(serverResponse)
                    
                } catch {
                    print(error)
                }
                
            }
            }.resume()
    }

}
