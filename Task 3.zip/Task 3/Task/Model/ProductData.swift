//
//  ProductData.swift
//  Task
//
//  Created by brn.developers on 8/1/18.
//  Copyright © 2018 Avast Technology. All rights reserved.
//

import Foundation
struct products : Decodable
{
    let user_currency:String
    let product_list: [productNames]
}
struct productNames : Decodable
{
    let name:String
    let product_image:String
    let product_description:String
    let actual_price:String
    let final_price:String
}
