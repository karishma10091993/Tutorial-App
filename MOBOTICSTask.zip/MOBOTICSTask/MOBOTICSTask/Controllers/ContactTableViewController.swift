//
//  ContactTableViewController.swift
//  MOBOTICSTask
//
//  Created by BharathKumar on 7/2/18.
//  Copyright © 2018 brn. All rights reserved.
//

import UIKit
import CoreData
class ContactTableViewController: UITableViewController,NSFetchedResultsControllerDelegate {
    let searchController = UISearchController(searchResultsController: nil)
    var frc :NSFetchedResultsController = NSFetchedResultsController<NSFetchRequestResult>()
    var frc1:NSFetchedResultsController = NSFetchedResultsController<NSFetchRequestResult>()
    var pc = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    func fetchRequest() -> NSFetchRequest<NSFetchRequestResult>
    {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName:"Contacts")
        let sorter = NSSortDescriptor(key: "firstName", ascending: true)
        fetchRequest.sortDescriptors = [sorter]
        return fetchRequest
    }
    func getFRC() -> NSFetchedResultsController<NSFetchRequestResult>
    {
        frc = NSFetchedResultsController(fetchRequest: fetchRequest(), managedObjectContext: pc, sectionNameKeyPath: nil, cacheName: nil)
        return frc
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        frc = getFRC()
        frc.delegate = self
        do
        {
            try frc.performFetch()
        }catch
        {
            print(error)
            return
        }
        self.tableView.reloadData()
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        searchController.searchBar.tintColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        searchController.searchBar.barStyle = .blackTranslucent
        definesPresentationContext = true
        self.navigationItem.searchController = searchController
        self.navigationItem.hidesSearchBarWhenScrolling = false
        self.navigationItem.leftBarButtonItem = self.editButtonItem
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searchController.isActive
        {
            let numberOfRows1 = frc1.sections?[section].numberOfObjects
            return numberOfRows1 ?? 0
        }else
        {
            let numberOfRows = frc.sections?[section].numberOfObjects
            return numberOfRows!
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "contactCell", for: indexPath) as! ContactTableViewCell
        if searchController.isActive
        {
            let item = frc1.object(at: indexPath) as! Contacts
            cell.contactName.text = item.firstName
            cell.contactImage.image = UIImage(data: (item.userImage)! as Data)
        }else
        {
            let item = frc.object(at: indexPath) as! Contacts
            cell.contactName.text = item.firstName
            cell.contactImage.image = UIImage(data: (item.userImage)! as Data)
        }
        return cell
    }
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.reloadData()
    }
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        
        return true
    }
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let deleteAlert = UIAlertController(title: "Would you like to delete this contact", message:"", preferredStyle: UIAlertControllerStyle.actionSheet)
            let deleteAction = UIAlertAction(title: "Delete", style: UIAlertActionStyle.destructive, handler: { (delete) in
                let managedObject : NSManagedObject = self.frc.object(at: indexPath) as! NSManagedObject
                self.pc.delete(managedObject)
                do
                {
                    try self.pc.save()
                }catch
                {
                    print(error)
                    return
                }
            })
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: nil)
            self.present(deleteAlert, animated: true, completion: nil)
            deleteAlert.addAction(deleteAction)
            deleteAlert.addAction(cancelAction)
        }
    }
    override func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        let addVC = self.storyboard?.instantiateViewController(withIdentifier: "contactDetailsVC") as! AddContactViewController
        if searchController.isActive
        {
            let item :Contacts = frc1.object(at:indexPath) as! Contacts
            addVC.item = item
            self.navigationController?.pushViewController(addVC, animated: true)
        }else
        {
            let item :Contacts = frc.object(at:indexPath) as! Contacts
            addVC.item = item
            self.navigationController?.pushViewController(addVC, animated: true)
        }
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if searchController.isActive
        {
            let item :Contacts = frc1.object(at:indexPath) as! Contacts
            UIApplication.shared.open(URL(string: "tel://\(item.mobileNumber!)")!, options: [:], completionHandler: nil)
        }else
        {
            let item :Contacts = frc.object(at:indexPath) as! Contacts
            UIApplication.shared.open(URL(string: "tel://\(item.mobileNumber!)")!, options: [:], completionHandler: nil)
        }
    }
    func searchBarIsEmpty() -> Bool
    {
        return searchController.searchBar.text?.isEmpty ?? true
    }
    func filterContextforSearchText(_ searchText:String)
    {
        frc1 = NSFetchedResultsController(fetchRequest: fetchRequest(), managedObjectContext: pc, sectionNameKeyPath: nil, cacheName: nil)
        frc1.fetchRequest.predicate = NSPredicate(format: "firstName Contains[C] %@",searchText)
        do {
            try frc1.performFetch()
        }
        catch  {
            print(error)
        }
        tableView.reloadData()
    }
}
extension ContactTableViewController:UISearchResultsUpdating
{
    func updateSearchResults(for searchController: UISearchController) {
        filterContextforSearchText(searchController.searchBar.text!)
    }
}
