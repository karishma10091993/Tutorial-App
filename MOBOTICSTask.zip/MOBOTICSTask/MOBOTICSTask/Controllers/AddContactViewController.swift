//
//  AddContactViewController.swift
//  MOBOTICSTask
//
//  Created by Bharath Kumar on 7/2/18.
//  Copyright © 2018 brn. All rights reserved.
//

import UIKit
import CoreData
class AddContactViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate,UIPickerViewDelegate,UIPickerViewDataSource{
    
    var item : Contacts? = nil   //Contacts Enity
    var countriesArray = [String]()  //To Store Countries List from the server
    
    var pc = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext //to get Persistent Container from app Delegate
    
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var firstNameTF: UITextField!
    @IBOutlet weak var lastNameTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var mobileNumberTF: UITextField!
    @IBOutlet weak var countryTF: UITextField!
    @IBOutlet weak var addContacts: UIButton!
    let picker = UIPickerView()
    //View Did Load
    override func viewDidLoad() {
        super.viewDidLoad()
        self.jsonParsing() //To Parse the Data from JSON
        countriesArray.append("Choose Country")
        //if the Item in the Contacts Entity is nil We have to add new Contact otherWise show the Existing contact from the Contacts Entity.
        if item == nil
        {
            self.navigationItem.title = "Add Contact"
        }
        else
        {
            self.navigationItem.title = item?.firstName
            userImage.image = UIImage(data: (item?.userImage)! as Data)
            addContacts.setTitle("Save", for: UIControlState.normal)
            firstNameTF.text = item?.firstName
            lastNameTF.text = item?.lastName
            emailTF.text = item?.email
            mobileNumberTF.text = item?.mobileNumber
            countryTF.text = item?.country
        }
       
        addContacts.layer.cornerRadius = 10
        self.navigationItem.largeTitleDisplayMode = .never
        userImage.layer.cornerRadius = userImage.frame.width/2
        countryTF.delegate = self
        emailTF.delegate = self
        mobileNumberTF.delegate = self
    }

// To Access the Camera or the Gallery Application
    
    @IBAction func onCamera(_ sender: Any) {
        let alert = UIAlertController(title:"Choose",message:nil, preferredStyle: .actionSheet)
        let cameraAction = UIAlertAction(title: "Camera", style: UIAlertActionStyle.default) { (camera) in
            let pickerController1 = UIImagePickerController()
            pickerController1.delegate = self
            pickerController1.sourceType = .camera
            pickerController1.allowsEditing = true
            
            self.present(pickerController1, animated: true, completion: nil)
        }
        let galleryAction = UIAlertAction(title: "Gallery", style: UIAlertActionStyle.default) { (gallery) in
            let pickerController = UIImagePickerController()
            pickerController.delegate = self
            pickerController.sourceType = UIImagePickerControllerSourceType.photoLibrary
            pickerController.allowsEditing = true
            
            self.present(pickerController, animated: true, completion: nil)
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: nil)
        alert.addAction(cameraAction)
        alert.addAction(galleryAction)
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    //To Pick the Photo From the app and Assign the image to UserImage if the Image is not nil
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage
        {
            userImage.image = image
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    //To dismiss the key Board
    @IBAction func dismissKeyBoard(_ sender: Any) {
        self.resignFirstResponder()
    }
    
    // Textfields Delegates Methos for Texfiled Validations
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == countryTF
        {
            countryTF.inputView = picker
           
            // ToolBar
            let toolBar = UIToolbar()
            toolBar.barStyle = .default
            toolBar.isTranslucent = true
            toolBar.tintColor = UIColor(red: 92/255, green: 216/255, blue: 255/255, alpha: 1)
            toolBar.sizeToFit()
            
            // Adding Button ToolBar
            let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(doneClick))
            let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
            let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelClick))
            toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
            toolBar.isUserInteractionEnabled = true
            countryTF.inputAccessoryView = toolBar

            picker.delegate = self
            picker.dataSource = self
            
        }
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == emailTF
        {
            if !isValidEmail(testStr: emailTF.text!){
                AlertSingleton.shared.showAlerts(tite: "Alert !", message: "Invalid Email ID", target: self, responder: {
                    self.emailTF.becomeFirstResponder()
                })
            }
        }else if textField == mobileNumberTF
        {
            if !isValidMobile(testStr: mobileNumberTF.text!){
                AlertSingleton.shared.showAlerts(tite: "Alert !", message: "Invalid Mobile Number", target: self, responder: {
                    self.mobileNumberTF.becomeFirstResponder()
                })
            }
        }
    }
    
    //Add the Data in to Entity After Verifyng that all the Texfields are filled
    
    @IBAction func addContact(_ sender: Any) {
        if firstNameTF.text == ""
        {
            AlertSingleton.shared.showAlerts(tite: "Alert !", message: "Enter Your First Name", target: self, responder: {
                self.firstNameTF.becomeFirstResponder()
            })
        }else if lastNameTF.text == ""
        {
            AlertSingleton.shared.showAlerts(tite: "Alert !", message: "Enter Your Last Name", target: self, responder: {
                self.lastNameTF.becomeFirstResponder()
            })
        }else if !isValidEmail(testStr: emailTF.text!){
            AlertSingleton.shared.showAlerts(tite: "Alert !", message: "Enter Valid Email ID", target: self, responder: {
                self.emailTF.becomeFirstResponder()
            })
        }else  if !isValidMobile(testStr: mobileNumberTF.text!){
            AlertSingleton.shared.showAlerts(tite: "Alert !", message: "Invalid Mobile Number", target: self, responder: {
                self.mobileNumberTF.becomeFirstResponder()
            })
        }
        else
        {
            if item == nil
            {
                let enityDescription = NSEntityDescription.entity(forEntityName: "Contacts", in: pc)
                let item = Contacts(entity:enityDescription! , insertInto: pc)
                
                item.userImage = UIImageJPEGRepresentation(userImage.image!,10.0) as Data?
                item.firstName = firstNameTF.text
                item.lastName = lastNameTF.text
                item.email = emailTF.text
                item.mobileNumber = mobileNumberTF.text
                item.country = countryTF.text
                
            }else
            {
                item?.userImage = UIImageJPEGRepresentation(userImage.image!,10.0) as Data?
                item?.firstName = firstNameTF.text
                item?.lastName = lastNameTF.text
                item?.email = emailTF.text
                item?.mobileNumber = mobileNumberTF.text
                item?.country = countryTF.text
            }
            do
            {
                try pc.save() //Save the Data to Entity
            }catch
            {
                print(error)
                return
            }
            navigationController!.popViewController(animated: true)
        }
    }
    
    // Email Validation Regex
    func isValidEmail(testStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: testStr)
        return result
    }
    //Mobile Number Regex
    func isValidMobile(testStr:String) -> Bool {
        let mobileRegex = "[0-9]{10}"
        let mobiletest = NSPredicate(format:"SELF MATCHES %@", mobileRegex)
        let result = mobiletest.evaluate(with: testStr)
        return result
    }
    
    
// Picker Function Delegate Methods
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return countriesArray.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return countriesArray[row]
    }

    //JSON Parsing
    func jsonParsing()
    {
        let url = URL(string: "https://restcountries.eu/rest/v1/all")
        guard let urlstring = url else {return}
        let task = URLSession.shared.dataTask(with: urlstring) { (data, response, error) in
            DispatchQueue.main.async {
                if error != nil
                {
                    print("error")
                }
                else
                {
                    guard let datais = data else{return}
                    do
                    {
                        let countriesList = try JSONSerialization.jsonObject(with:datais, options: JSONSerialization.ReadingOptions.allowFragments) as! [Any]
                        for i in countriesList
                        {
                            let country:[String:Any] = i as! [String : Any]
                            self.countriesArray.append(country["name"]! as! String)
                        }
                    }catch
                    {
                        print(error)
                    }
                }
            }
        }
        task.resume()
    }
    @objc func doneClick() {
       let indexpath = picker.selectedRow(inComponent:0)
        if indexpath == 0
        {
            countryTF.text = ""
        }else
        {
       countryTF.text = countriesArray[indexpath]
        }
        countryTF.resignFirstResponder()
    }
    @objc func cancelClick() {
        countryTF.resignFirstResponder()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
