//
//  ContactTableViewCell.swift
//  MOBOTICSTask
//
//  Created by Bharath Kumar on 7/2/18.
//  Copyright © 2018 brn. All rights reserved.
//

import UIKit

class ContactTableViewCell: UITableViewCell {
    @IBOutlet weak var contactImage: UIImageView!
    @IBOutlet weak var contactName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        contactImage.layer.cornerRadius = contactImage.frame.width/2
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
