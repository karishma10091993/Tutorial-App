//
//  AlertSingleton.swift
//  MOBOTICSTask
//
//  Created by Bharath Kumar on 7/6/18.
//  Copyright © 2018 brn. All rights reserved.
//

import UIKit

class AlertSingleton: NSObject {
    static let shared = AlertSingleton()
    override init() {
    }
    func showAlerts(tite:String,message:String,target:UIViewController,responder:@escaping ()->Void)
    {
        let alerts = UIAlertController(title:tite, message:message, preferredStyle: UIAlertControllerStyle.alert)
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.cancel, handler: { (alert) in
            responder()
        })
        target.present(alerts, animated: true, completion: nil)
        alerts.addAction(okAction)
    }
}
