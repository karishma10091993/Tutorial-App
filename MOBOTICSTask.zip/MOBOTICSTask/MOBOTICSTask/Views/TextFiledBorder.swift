//
//  TextFiledBorder.swift
//  MOBOTICSTask
//
//  Created by Bharath Kumar on 7/5/18.
//  Copyright © 2018 brn. All rights reserved.
//

import UIKit

class TextFiledBorder: UITextField {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        let border = CALayer()
        let width = CGFloat(2.0)
        border.borderColor = #colorLiteral(red: 0, green: 0.5898008943, blue: 1, alpha: 1)
        border.frame = CGRect(x:0, y: self.frame.size.height - width, width:self.frame.size.width+50, height: self.frame.size.height)
        border.borderWidth = width
        self.layer.addSublayer(border)
        self.layer.masksToBounds = true
    }
    
}
