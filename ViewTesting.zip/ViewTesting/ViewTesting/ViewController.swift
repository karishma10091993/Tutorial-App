//
//  ViewController.swift
//  ViewTesting
//
//  Created by kireeti on 19/11/18.
//  Copyright © 2018 KireetiSoft. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var headView: HeaderView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.navigationController?.navigationBar.isHidden = true
    self.headView.companyLbl.text = "My Company"
    self.headView.pharmaLbl.text = "My Pharmasoft Company"
        self.headView.sideMenu.addTarget(self, action: #selector(sideMenuBtnAction(sender: ))
            , for: .touchUpInside)
        self.headView.optionMenu.addTarget(self, action: #selector(optionMenuAction(_:)), for: .touchUpInside)
        
    }

    @objc func sideMenuBtnAction(sender: UIButton) {
        print("side menu button action")
    }
    @objc func optionMenuAction(_ sender: UIButton) {
        print("=== option menu action ===")
    }
    


}

