//
//  HeaderView.swift
//  ViewTesting
//
//  Created by kireeti on 19/11/18.
//  Copyright © 2018 KireetiSoft. All rights reserved.
//

import UIKit

class HeaderView: UIView {

    @IBOutlet private var newView:UIView?
    // other outlets
    
    @IBOutlet var optionMenu: UIButton!
    @IBOutlet var sideMenu: UIButton!
    @IBOutlet var companyLbl: UILabel!
    @IBOutlet var pharmaLbl: UILabel!
    override init(frame: CGRect) { // for using CustomView in code
        super.init(frame: frame)
        self.commonInit()
//        super.init(frame: CGRect(x: 0, y: 0, width: (newView?.frame.width)!, height: (newView?.frame.width)!))
    }
    
    required init?(coder aDecoder: NSCoder) { // for using CustomView in IB
        super.init(coder: aDecoder)
        self.commonInit()
    }
    
    private func commonInit() {
        Bundle.main.loadNibNamed("HeaderView", owner: self, options: nil)
        guard let content = newView else { return }
        content.frame = self.bounds
        content.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        self.addSubview(content)
    }

}
