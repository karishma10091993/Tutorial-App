//
//  ThirdViewController.swift
//  ViewTesting
//
//  Created by kireeti on 19/11/18.
//  Copyright © 2018 KireetiSoft. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    @IBOutlet var headView: HeaderView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.navigationController?.navigationBar.isHidden = true
        
        
        self.headView.companyLbl.text = "Third My Company"
        self.headView.pharmaLbl.text = "Third Pharmasoft"
        self.headView.sideMenu.addTarget(self, action: #selector(sideMenuBtnAction(sender: ))
            , for: .touchUpInside)
        self.headView.optionMenu.addTarget(self, action: #selector(optionMenuAction(_:)), for: .touchUpInside)
    }

    @objc func sideMenuBtnAction(sender: UIButton) {
        print("third side menu button action")
    }
    @objc func optionMenuAction(_ sender: UIButton) {
        print("===third option menu action ===")
    }
    

}
