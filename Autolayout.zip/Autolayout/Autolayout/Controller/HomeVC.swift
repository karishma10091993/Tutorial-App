//
//  HomeVC.swift
//  Autolayout
//
//  Created by kireeti on 10/08/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import UIKit

class HomeVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

   
    }

   

}
