//
//  ViewController.swift
//  Autolayout
//
//  Created by kireeti on 09/08/18.
//  Copyright © 2018 KireetiSoftSolutions. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet var sideView: UIView!
    @IBOutlet var menuTableView: UITableView!
    @IBOutlet var sidebarBtn: UIButton!
    
    
    
    var isSideViewOpen: Bool = false
    var sideMenuItems = ["home1","Profile1","Message","favourite","Setting","Shutdown"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        sideView.isHidden = true
        menuTableView.backgroundColor = UIColor.groupTableViewBackground
        isSideViewOpen = false
        menuTableView.frame = CGRect.init(x: -self.menuTableView.frame.size.width/2, y: 0, width: self.menuTableView.frame.size.width, height: self.menuTableView.frame.size.height)
        self.view.layoutIfNeeded()
        
        // Animation
        

    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0
        {
           let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "HomeVC")
           // self.present(homeVC!, animated: true, completion: nil)
          self.navigationController?.pushViewController(homeVC!, animated: true)
        }
    }
    
    
    
    
    @IBAction func sidebar(_ sender: Any) {
        
        
        menuTableView.isHidden = false
        sideView.isHidden = false
       
        if !isSideViewOpen{
            isSideViewOpen = true//0
//            sideView.frame = CGRect(x: 0, y: 88, width: 0, height: 499)
//            menuTableView.frame = CGRect(x: 0, y: 0, width: 0, height: 499)
//            UIView.setAnimationDuration(0.3)
//            UIView.setAnimationDelegate(self)
//            UIView.beginAnimations("TableAnimation", context: nil)//1
//            sideView.frame = CGRect(x: 0, y: 88, width: 259, height: 499)
//            menuTableView.frame = CGRect(x: 0, y: 0, width: 259, height: 499)
//            UIView.commitAnimations()
            menuTableView.frame = CGRect.init(x: -self.sideView.frame.size.width, y: 0, width: self.sideView.frame.size.width, height: self.sideView.frame.size.height)
            self.sideView.addSubview(self.menuTableView)
            self.view.layoutIfNeeded()
            
            
//            UIView.animate(withDuration: 1.0, animations: {
//                <#code#>
//                
//            }) { (true) in
//                <#code#>
//            }
        }else{
            menuTableView.isHidden = true
            sideView.isHidden = true
            isSideViewOpen = false
//            sideView.frame = CGRect(x: 0, y: 88, width: 259, height: 499)
//            menuTableView.frame = CGRect(x: 0, y: 0, width: 259, height: 499)
//            UIView.setAnimationDuration(0.3)
//            UIView.setAnimationDelegate(self)
//            UIView.beginAnimations("TableAnimation", context: nil)
//            sideView.frame = CGRect(x: 0, y: 88, width: 0, height: 499)
//            menuTableView.frame = CGRect(x: 0, y: 0, width: 0, height: 499)
//            sideView.bringSubview(toFront: menuTableView)
//            UIView.commitAnimations()
            menuTableView.frame = CGRect.init(x: self.sideView.frame.size.width, y: 0, width: self.sideView.frame.size.width, height: self.sideView.frame.size.height)
              self.sideView.addSubview(self.menuTableView)
            self.view.layoutIfNeeded()
        }
        
        
    
        
    }

    
    
    
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sideMenuItems.count
    }
    
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        cell.img.image = UIImage.init(named: sideMenuItems[indexPath.row])
        cell.nameLbl.text = sideMenuItems[indexPath.row]
        return cell
    }
}

